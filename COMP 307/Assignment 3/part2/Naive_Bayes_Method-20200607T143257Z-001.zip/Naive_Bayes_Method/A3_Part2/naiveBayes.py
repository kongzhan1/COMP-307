def data_reader(training_file, testing_file):
    try:
        train_file = open(training_file, 'r')
        training_data = train_file.readlines()
        train_file.close()
        test_file = open(testing_file, 'r')
        test_data = test_file.readlines()
        test_file.close()

        train_set, attr1 = process_training_data(training_data)
        test_set, attr2 = process_testing_data(test_data)
        number_of_attributes = attr2

        return train_set, test_set, number_of_attributes
    except():
        print("File reading Error")
        pass


def process_training_data(data_set):
    train_set = []
    for line in data_set:
        if line != '\n':
            attri = line.split()
            attributes = []
            number_of_attributes = len(attri) - 1
            for i in range(number_of_attributes):
                attributes.append(attri[i])
                # make class value separated
            train_set.append([attributes, attri[number_of_attributes]])
    return train_set, number_of_attributes


def process_testing_data(data_set):
    testing_set = []
    for line in data_set:
        if line != '\n':
            attri = line.split()
            attributes = []
            number_of_attributes = len(attri)
            for i in range(number_of_attributes):
                attributes.append(attri[i])
            testing_set.append(attributes)
    return testing_set, number_of_attributes


def check_spam(train_data):
    spam = 0
    non_spam = 0
    for instance in train_data:
        # get class
        if instance[1] == '1':
            spam += 1
        else:
            non_spam += 1
    return spam, non_spam


def probabilityTable(train_data, number_of_attri, spam, non_spam):
    total_instance = spam + non_spam
    prob_table = []
    check_num = 0  # check whether a consequence never happens or not

    c0a0, c0a1, c1a0, c1a1, check_num, probability_table = calculate_num(train_data, number_of_attri)

    if check_num > 0:
        spam += 1
        non_spam += 1
        new_prob_table = []
        for i in probability_table:
            c0a0 = i[0] + 1
            c0a1 = i[1] + 1
            c1a0 = i[2] + 1
            c1a1 = i[3] + 1
            print(c1a1)
            new_prob_table.append([c0a0, c0a1, c1a0, c1a1])
        probability_table = new_prob_table
    for i in probability_table:
        prob_table.append([float(i[0]) / non_spam, float(i[1]) / non_spam, float(i[2]) / spam, float(i[3]) / spam])

    return probability_table, prob_table, spam, non_spam


# return different class with different attributes number.
def calculate_num(train_set, number_of_attri):
    global class_0_attri_0, class_0_attri_1, class_1_attri_0, class_1_attri_1
    num = 0
    table = []
    for i in range(number_of_attri):
        class_0_attri_0 = 0
        class_0_attri_1 = 0
        class_1_attri_0 = 0
        class_1_attri_1 = 0
        for instance in train_set:
            if instance[1] == '0' and instance[0][i] == '0':
                class_0_attri_0 += 1
            if instance[1] == '0' and instance[0][i] == '1':
                class_0_attri_1 += 1
            if instance[1] == '1' and instance[0][i] == '0':
                class_1_attri_0 += 1
            if instance[1] == '1' and instance[0][i] == '1':
                class_1_attri_1 += 1
        # if a sequence never happens
        if class_0_attri_0 == 0 or class_0_attri_1 == 0 or class_1_attri_0 == 0 or class_1_attri_1 == 0:
            num += 1
        table.append([class_0_attri_0, class_0_attri_1, class_1_attri_0, class_1_attri_1])
    return class_0_attri_0, class_0_attri_1, class_1_attri_0, class_1_attri_1, num, table


def classifier(test_data, prob_table, spam, non_spam, number_of_attri):
    total = spam + non_spam
    counter = 0
    for instance in test_data:
        a = float(spam) / total
        b = float(non_spam) / total
        counter += 1
        for i in range(number_of_attri):
            if instance[i] == '1':
                a *= prob_table[i][3]
                b *= prob_table[i][1]
            else:
                a *= prob_table[i][2]
                b *= prob_table[i][0]
        if a > b:
            print("Probability for Spam  is {},Probability for non-spam is {}.".format(a, b))
            print("Instance :", counter, " is ", 'spam')

        else:
            print("Probability for Spam  is {},Probability for non-spam is {}.".format(a, b))
            print("Instance :", counter, " is ", 'non_spam')


if __name__ == '__main__':
    path_labeled = 'spamLabelled.dat'
    path_unlabeled = 'spamUnlabelled.dat'
    train_data, test_data, number_of_attri = data_reader(path_labeled, path_unlabeled)
    spam_number, non_spam_number = check_spam(train_data)
    # visualise(train_data)
    print(spam_number)
    print(non_spam_number)
    probability_table, prob_table, spam, non_spam = probabilityTable(train_data, number_of_attri, spam_number,
                                                                     non_spam_number)
    spam_number = spam
    non_spam_number = non_spam
    # print(spam_number, "aaa")
    # print(non_spam_number)
    classifier(test_data, prob_table, spam, non_spam, number_of_attri)

    for i in range(number_of_attri):
        print("P(F{} = 0| C = 0) = {}".format(i, prob_table[i][0]))
        print("P(F{} = 0| C = 1) = {}".format(i, prob_table[i][1]))
        print("P(F{} = 1| C = 0) = {}".format(i, prob_table[i][2]))
        print("P(F{} = 1| C = 1) = {}".format(i, prob_table[i][3]))
        print("\n")
